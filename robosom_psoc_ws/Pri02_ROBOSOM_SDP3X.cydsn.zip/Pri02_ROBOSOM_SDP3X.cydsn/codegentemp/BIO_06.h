/*******************************************************************************
* File Name: BIO_06.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_BIO_06_H) /* Pins BIO_06_H */
#define CY_PINS_BIO_06_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "BIO_06_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 BIO_06__PORT == 15 && ((BIO_06__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    BIO_06_Write(uint8 value);
void    BIO_06_SetDriveMode(uint8 mode);
uint8   BIO_06_ReadDataReg(void);
uint8   BIO_06_Read(void);
void    BIO_06_SetInterruptMode(uint16 position, uint16 mode);
uint8   BIO_06_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the BIO_06_SetDriveMode() function.
     *  @{
     */
        #define BIO_06_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define BIO_06_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define BIO_06_DM_RES_UP          PIN_DM_RES_UP
        #define BIO_06_DM_RES_DWN         PIN_DM_RES_DWN
        #define BIO_06_DM_OD_LO           PIN_DM_OD_LO
        #define BIO_06_DM_OD_HI           PIN_DM_OD_HI
        #define BIO_06_DM_STRONG          PIN_DM_STRONG
        #define BIO_06_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define BIO_06_MASK               BIO_06__MASK
#define BIO_06_SHIFT              BIO_06__SHIFT
#define BIO_06_WIDTH              1u

/* Interrupt constants */
#if defined(BIO_06__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in BIO_06_SetInterruptMode() function.
     *  @{
     */
        #define BIO_06_INTR_NONE      (uint16)(0x0000u)
        #define BIO_06_INTR_RISING    (uint16)(0x0001u)
        #define BIO_06_INTR_FALLING   (uint16)(0x0002u)
        #define BIO_06_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define BIO_06_INTR_MASK      (0x01u) 
#endif /* (BIO_06__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define BIO_06_PS                     (* (reg8 *) BIO_06__PS)
/* Data Register */
#define BIO_06_DR                     (* (reg8 *) BIO_06__DR)
/* Port Number */
#define BIO_06_PRT_NUM                (* (reg8 *) BIO_06__PRT) 
/* Connect to Analog Globals */                                                  
#define BIO_06_AG                     (* (reg8 *) BIO_06__AG)                       
/* Analog MUX bux enable */
#define BIO_06_AMUX                   (* (reg8 *) BIO_06__AMUX) 
/* Bidirectional Enable */                                                        
#define BIO_06_BIE                    (* (reg8 *) BIO_06__BIE)
/* Bit-mask for Aliased Register Access */
#define BIO_06_BIT_MASK               (* (reg8 *) BIO_06__BIT_MASK)
/* Bypass Enable */
#define BIO_06_BYP                    (* (reg8 *) BIO_06__BYP)
/* Port wide control signals */                                                   
#define BIO_06_CTL                    (* (reg8 *) BIO_06__CTL)
/* Drive Modes */
#define BIO_06_DM0                    (* (reg8 *) BIO_06__DM0) 
#define BIO_06_DM1                    (* (reg8 *) BIO_06__DM1)
#define BIO_06_DM2                    (* (reg8 *) BIO_06__DM2) 
/* Input Buffer Disable Override */
#define BIO_06_INP_DIS                (* (reg8 *) BIO_06__INP_DIS)
/* LCD Common or Segment Drive */
#define BIO_06_LCD_COM_SEG            (* (reg8 *) BIO_06__LCD_COM_SEG)
/* Enable Segment LCD */
#define BIO_06_LCD_EN                 (* (reg8 *) BIO_06__LCD_EN)
/* Slew Rate Control */
#define BIO_06_SLW                    (* (reg8 *) BIO_06__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define BIO_06_PRTDSI__CAPS_SEL       (* (reg8 *) BIO_06__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define BIO_06_PRTDSI__DBL_SYNC_IN    (* (reg8 *) BIO_06__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define BIO_06_PRTDSI__OE_SEL0        (* (reg8 *) BIO_06__PRTDSI__OE_SEL0) 
#define BIO_06_PRTDSI__OE_SEL1        (* (reg8 *) BIO_06__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define BIO_06_PRTDSI__OUT_SEL0       (* (reg8 *) BIO_06__PRTDSI__OUT_SEL0) 
#define BIO_06_PRTDSI__OUT_SEL1       (* (reg8 *) BIO_06__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define BIO_06_PRTDSI__SYNC_OUT       (* (reg8 *) BIO_06__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(BIO_06__SIO_CFG)
    #define BIO_06_SIO_HYST_EN        (* (reg8 *) BIO_06__SIO_HYST_EN)
    #define BIO_06_SIO_REG_HIFREQ     (* (reg8 *) BIO_06__SIO_REG_HIFREQ)
    #define BIO_06_SIO_CFG            (* (reg8 *) BIO_06__SIO_CFG)
    #define BIO_06_SIO_DIFF           (* (reg8 *) BIO_06__SIO_DIFF)
#endif /* (BIO_06__SIO_CFG) */

/* Interrupt Registers */
#if defined(BIO_06__INTSTAT)
    #define BIO_06_INTSTAT            (* (reg8 *) BIO_06__INTSTAT)
    #define BIO_06_SNAP               (* (reg8 *) BIO_06__SNAP)
    
	#define BIO_06_0_INTTYPE_REG 		(* (reg8 *) BIO_06__0__INTTYPE)
#endif /* (BIO_06__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_BIO_06_H */


/* [] END OF FILE */
